# Memory Index

## Sub-indexes (load by session type)
- [MEMORY-PROJECTS.md](MEMORY-PROJECTS.md): Active builds: what each project is, where it stands, links to specs
- [MEMORY-STACK.md](MEMORY-STACK.md): Tools, APIs, infra details: what's deployed, credentials pattern, key gotchas
- [MEMORY-CLIENTS.md](MEMORY-CLIENTS.md): Client and collaborator context (if applicable)

## Always loaded: Claude behavior + identity
- [user_name.md](user_name.md): Your identity, accounts, timezone, communication style
- [working_style.md](working_style.md): How you give instructions, how you like Claude to respond
- [feedback_tone.md](feedback_tone.md): Writing style rules (no jargon, no filler, direct)
- [feedback_behavior.md](feedback_behavior.md): Behavioral rules Claude must follow (challenge assumptions, no yes-manning)

## Reference (load when relevant)
- [reference_stack.md](reference_stack.md): Technology stack details: languages, frameworks, deploy targets
- [reference_tools.md](reference_tools.md): Tool configs: API keys patterns, which model for which task, rate limits

---

## Memory file authoring rules

1. Load the index every session. Never read sub-indexes unless that topic comes up.
2. A memory file should answer "what does Claude need to know about X that is NOT in the code?"
3. Never put code patterns, file paths, or git history in memory. Those live in the codebase.
4. Feedback files are behavioral rules. One rule per file. Lead with the rule, then why.
5. Add a new file only when you have re-explained something to Claude 2+ times.
