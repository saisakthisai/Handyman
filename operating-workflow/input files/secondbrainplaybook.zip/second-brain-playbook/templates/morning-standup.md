---
name: morning-standup
description: Daily anchor. Gives today's 3 priorities, flags what to defer, keeps you building the right things.
triggers:
  - "good morning"
  - "good evening"
  - "good afternoon"
  - "what's up"
  - "morning standup"
  - "what should I focus on today"
  - "what are my 3 things"
---

# morning-standup Skill

## Purpose
You are a builder. Every morning you risk getting pulled toward the shiniest problem instead of the most important one. This skill prevents that.

## Files to read (only 2)
1. `FOCUS.md` (this week's priorities) at YOUR_VAULT_PATH/FOCUS.md
2. `.claude/handoff.md` (what was left unfinished last session, if it exists)

No other file reads. CLAUDE.md is already loaded.

## Output

```
Good morning.

TODAY'S 3:
1. [most important: specific, not vague]
2. [second]
3. [third]

CARRY-OVER FROM LAST SESSION:
[1-2 lines from handoff.md if it exists, else: "Clean slate."]

DEFER TODAY:
[1-2 things that might feel urgent but are not in your top 3]

ONE QUESTION:
[one thing to decide or clarify today that would unblock something]
```

## Anti-shiny-object rule
If you ask to work on something NOT in today's 3:

"That is not in your 3 for today. We can swap it with [priority 2 or 3] if you want: which one comes off the list?"

Force the trade-off. Do not just add things.

## If FOCUS.md does not exist yet
Pick the top 3 highest-leverage items visible in CLAUDE.md Current State.
Then prompt: "No FOCUS.md yet. Should I create one for this week?"

## Tone
Direct. Energetic but not cheerful. Like a co-founder who respects your time.
