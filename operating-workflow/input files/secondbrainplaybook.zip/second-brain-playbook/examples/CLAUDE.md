# [Your Project Name]

## What This Is
[One sentence description of your command center / working directory]

## Hard Rules (never break these)
- [Rule 1: one line, no explanation needed here]
- [Rule 2]
- [Rule 3]

Keep this list under 10 rules. If you have more, they belong in memory files.

## Current State
[2-3 sentences about what you are currently building or working on. Update at each session-end.]

As of [date]: [what is the status].

## Paths
- Vault: `[path to your Obsidian vault]`
- FOCUS.md: `[path]/FOCUS.md`
- Working directory: `[path to your project folder]`

## Writing Style (one-liners only: SOPs in .claude/rules/)
- No em-dashes
- Direct statements, not hedged ones
- [Your style rule]

See `.claude/rules/writing-sop.md` for full writing guidelines.

---

## What NOT to put in CLAUDE.md

Keep CLAUDE.md under 3KB. Everything else goes in:
- `.claude/rules/`: SOPs, long rule lists, trigger tables
- Memory files: behavioral feedback, identity, stack details
- Skill files: workflow-specific SOPs live in the skill that needs them
- Obsidian vault: project knowledge, research, meeting notes, specs

The test: if Claude only needs this for one specific type of work, it does not belong in CLAUDE.md.
