# The Second Brain Behind the Agent

A playbook for giving your AI agent a real second brain: an organized place to read your work, your knowledge, and your many-context life from, not just a memory of your conversations.

**For:** the Hermes cohort (and anyone running a personal AI agent)
**Companion to:** the talk *"The Second Brain Behind the Agent"* (PDF in this folder: read it first)

---

## Start here: the one idea

Your agent has memory. Does it have a **brain to remember from?**

Hermes, G-Brain, Mem0, Honcho: these give your agent **memory of your conversations**. That is real, and it matters. But they do not answer a different question: *where does your actual work, your knowledge, and your many-context life physically live?*

An agent that remembers what you said, but has no organized place to read your world from, is **recalling a pile, not navigating a library.**

This playbook builds the library. It is one folder of markdown files (an Obsidian vault), structured so an agent never has to guess where anything goes. That is the whole trick. Everything below is the detail.

> **Two layers, both worth having.** Conversation-memory tools (G-Brain, Mem0, Honcho, Hermes' own memory) and a second brain (Obsidian) are **partners, not replacements.** One answers *"what does my agent remember about me?"* The other answers *"where does my actual knowledge and work live?"* Keep both. The closing section returns to this.

---

## A note on honesty (read this before you build)

This system is **proven on Claude Code.** I have run it for months: one agent at the center, three isolated vaults, a rotation of skills, a memory index loaded every session. It runs my real days.

I have **not yet wired Obsidian into Hermes myself.** That is my next build. So treat this playbook as two things:

1. **The architecture**: vault as second brain, isolated walls, repeated taxonomy, memory layers, skills. This is tool-neutral and it ports straight to Hermes.
2. **The reference wiring**: the exact Claude Code mechanics (file paths, skill format). This is the proven implementation you translate from.

`HERMES-TRANSLATION.md` is the bridge between the two, with a checklist of what each of you verifies on your own machine. No hand-waving. Where something is proven, it says so. Where it is to-verify, it says that too.

---

## The shape of it

One operating system. As many contexts (companies, projects, life) as you run.

```
1    agent at the center
3    vaults ("walls"), fully isolated      ← example; use as many as you have contexts
~5   skills active every day               ← from a larger library you pull from
1    memory index, loaded every session
```

None of this is theory. It runs every day: standups, brain-dumps, content, outreach, and the supervision of a second agent all flow through it.

---

## The walls: separate vaults, on purpose

A single vault lets two contexts bleed into each other. **Separate walls** give you:

- **Hard isolation**: one context cannot leak into another.
- **The right person sees only their world**: a co-founder syncs to one wall, not all of them.
- **Every skill fenced** to read only its own wall.

```
Wall 01: Context A     (e.g. a company)        synced with → its people
Wall 02: Context B     (e.g. another company)  synced with → its people
Wall 03: Personal      (cross-context + you)   private → just you + your agent
```

Sync to other people is handled by **Obsidian itself**, end to end, not by the agent. That local-file simplicity is also your privacy model: the vaults never leave your machine.

---

## Inside a wall: the same shape, every time

Every wall uses the **identical folder taxonomy.** This is the feature, not a detail. Because the shape never changes, the agent never has to guess where something goes.

```
YourWall/
├─ 00-Inbox        // longer raw notes and brain-dumps land here, unsorted
├─ 01-Projects     // active builds
├─ 02-People       // who you work with
├─ 04-Knowledge    // the durable stuff
├─ 05-Content      // drafts, posts, outputs
├─ 09-Meetings     // call notes, by person
├─ 12-Products     // what you ship
└─ _Vault-Bridge.md  // the index your agent reads first
```

A meeting note **always** lands in `09-Meetings`. A longer raw note **always** starts in `00-Inbox`. Predictable structure is what turns *"store this somewhere"* into automatic routing. **The repetition is the feature.**

> Two inboxes, on purpose. A quick one-line `capture:` lands in **`FOCUS.md`'s inbox** (your fast triage buffer, reviewed weekly). A longer note or brain-dump goes in the **`00-Inbox` folder**. Don't go looking for one-liners in `00-Inbox`: they live in `FOCUS.md`.

(An empty copy of this taxonomy is in `vault-skeleton/`: drop it into Obsidian to start.)

---

## How the agent connects: boringly simple

A vault is just a folder of markdown files on your machine. So the agent needs exactly one thing: **permission to read and write that folder.**

No special API. No server. No cloud database. The agent runs on the same machine as the vault, and the vault is right there on disk:

```
read · write · search · link
```

That is the entire mechanism. (How you grant that access differs by agent: see `HERMES-TRANSLATION.md`.)

---

## The memory layers

Your second brain maps cleanly onto the **five-layer memory model** Vignesh teaches. The point: memory is not a black box. It is human-readable files plus an index pulled into context at the start of every session.

| # | Layer | What it is | Where it lives |
|---|-------|-----------|----------------|
| 1 | Working memory | the live session + the handoff note | session + `handoff.md` |
| 2 | Episodic | what worked, what did not, moods, growth | feedback + growth log |
| 3 | Semantic | durable facts, the knowledge base | `04-Knowledge/` + memory topic files |
| 4 | Cross-session retrieval | the master index loaded at every start | `MEMORY.md` |
| 5 | Skill memory | reusable workflows and procedures | your skills folder |

The second brain (Obsidian) is where layers 2, 3, and 5 physically live and stay browsable by **you**. The conversation-memory tools sit alongside, strongest at layers 1 and 4.

---

## The daily rhythm

The system is not a dashboard you maintain. It is a rhythm you run.

```
MORNING        "good morning"   → agent reads FOCUS.md, hands you today's 3 priorities
START A BLOCK  session-start    → shows the handoff, loads only the context for that topic
WHILE WORKING  capture: [thing] → fire-and-forget, routed to the right place; back to work
               (pull any library skill when you reach that step)
END A BLOCK    session-end      → writes the handoff, updates current state
END OF DAY     daily            → what moved, tomorrow's anchor
FRIDAY         week-review      → what shipped, what stalled, what's next
```

**FOCUS.md is the single most important file.** This week's top 3, what you're waiting on, what you intentionally deferred. The morning standup reads it; everything anchors to it. Update it every Monday.

---

## Session skills vs library skills

The mistake everyone makes is trying to keep every skill in their head (or their context window). Don't.

```
SESSION SKILLS  (~5, active every day)
  morning-standup · session-start · capture · session-end · status

LIBRARY SKILLS  (everything else: pull when you reach that work)
  person-brief · week-review · daily · compound-capture · your own ...
```

Library skills live on disk. You call them with their name when you need them. **That is the wiring. There is no other wiring.** The flow is human-driven: you are the orchestrator, the agent follows your instructions, not a pre-programmed pipeline.

If you later want automation (a morning brief delivered without you typing anything), that is a **cron** layer added once your manual rhythm is solid. See `SKILL-AND-CRON.md`.

---

## One agent can raise another

The part worth aspiring to: a mature, structured agent can **supervise and cross-train** a second one. Give your primary agent visibility into where the second agent works, and it can watch, guide, and review on your behalf while you sleep or step away.

The structured second brain on one side raising the conversational agent on the other. (This is also the honest frontier of my own setup: giving the second agent its own vault is the next build.)

---

## What's in this playbook

```
second-brain-playbook/
  README.md                       ← this file (the concept)
  HERMES-TRANSLATION.md           ← proven-on-Claude-Code → verify-on-Hermes bridge + checklist
  QUICKSTART.md                   ← zero to a working rhythm in ~45 minutes
  SKILL-AND-CRON.md               ← write your own skills + automate them
  THOUGHT-PARTNER-CALIBRATION.md  ← turn the agent into a calibrated counterweight (bonus)
  OPERATING-MANUAL-CASE-STUDY.md  ← how that calibration file was actually built (bonus)
  templates/                      ← genericized session skills (placeholders only)
  bonus-skills/                   ← strategic-partner + strategic-lenses (the counterweight, on demand)
  examples/                       ← FOCUS.md, MEMORY.md, _Vault-Bridge.md, minimal global-rules
  vault-skeleton/                 ← the empty folder taxonomy: drop into Obsidian
  The Second Brain Behind the Agent.pdf   ← the talk (the visual "why")
```

> **Bonus: the thought-partner layer.** The second brain gives your agent a place to read your world from. The two `*-CALIBRATION` / `*-CASE-STUDY` docs plus `bonus-skills/` go further: they show how to make the agent a *calibrated counterweight to your thinking*, not just a memory. That layer is optional, and it is the part people feel most. Start with the rhythm; add it when the basics are running.

---

## The only metric that matters

You know it is working when:

1. You say "good morning" and in 30 seconds you know your 3 things.
2. You start a block and the agent knows exactly where you left off.
3. You call a library skill only when you need it, and it just works.
4. Your agent never has to guess where a note goes.
5. You are **using** the system, not reorganizing it.

The goal is not a beautiful system. The goal is a day where you did the work.

> Build yours. Verify the agent-specific wiring as you go. No hand-waving.
