# 04-Knowledge

The durable stuff. Processed references, frameworks, evergreen notes.

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
