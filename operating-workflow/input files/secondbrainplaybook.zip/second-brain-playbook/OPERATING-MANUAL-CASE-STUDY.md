# The Operating Manual: How It Was Actually Built

Companion to `THOUGHT-PARTNER-CALIBRATION.md`. That guide covers the whole system. This one is a deep dive on the single file that makes the agent a thought partner instead of an assistant: the operating manual that tells it how to collaborate with you specifically.

From Renuka, reconstructed from the actual artifacts and their order, not from memory of the process. The personal findings are stripped out; the method is what transfers.

---

## The headline finding

The operating manual was not written. It was **fused.**

Two independent streams existed before it, built for different reasons over roughly three weeks. The manual is what happened when they were forced together on one day. That is the whole point: the quality comes from the fusion, and building only one stream gets you a weak version.

- **Stream A, top-down:** formal psychometric data, read raw.
- **Stream B, bottom-up:** empirical behavioral observations, captured every session, especially the ones born from real failures.

Assessment data alone is generic personality theory. Session observations alone are anecdote. The manual has predictive force because the assessment predicts a failure mode and the observation log confirms it actually happened in real work. The rule then fires with a trigger the next time the pattern starts.

---

## The evolution, in phases

### Phase 0: The stated-preference seed

The earliest ancestor is a small feedback file created from one direct instruction, roughly:

> "You are my strategic thought partner, not my yes-man. Agree or challenge based on what is the right path forward."

That became a single feedback memory: a *why* (I run fast across multiple businesses and need scope-creep pushback) and a *how-to-apply* (critique before presenting, say "I disagree" with reasoning, sequence instead of agreeing to six things).

This is where most people stop. It is a stated preference: behavioral, generic, no evidence base. It produced a less agreeable assistant. It did not produce a calibrated counterweight, because it did not yet know *where specifically* I go wrong.

### Phase 1: Empirical accumulation (~3 weeks)

In parallel, a growth log accumulated one behavioral observation per session. Not theory. Recorded incidents. The clearest worked example: a real paid-API mistake, credits spent on the wrong list, turned into a permanent rule in under 30 seconds ("always confirm before spending on any paid API"). That rule was not derived from a personality test. It was derived from a specific failure, and it became one of the hardest gates in the system.

Other observations in this window: testing whether captured knowledge actually fires under pressure, demanding a pre-mortem before execution, naming a personal toolkit of decision frames. This stream is bottom-up: observed behavior becomes a captured pattern. Critically, it captured both failures and validated judgment calls, so the system did not drift toward bland caution.

### Phase 2: The data injection

Four formal assessment reports were read directly (Clifton StrengthsFinder, an SDI conflict instrument, an iEQ9 Enneagram, a Big Five). They spanned several years, which matters: consistency across instruments and time is signal.

The decisive choice: the **raw reports were read, not a self-summary.** The value lives in the findings a person would not volunteer about themselves: a reframing pattern that hides losses, a structural gap the person will not naturally cover, a tendency that runs hot where caution is needed. (The specific findings are personal; what transfers is *reading the raw data and extracting the unflattering structural truths.*) This stream is top-down: validated instruments produce structural findings, including the ones you would not write down yourself.

### Phase 3: The synthesis

The manual was written by fusing both streams the same day. The structure is the important part. Every rule has three components:

- **The rule** (a counterweight behavior)
- **Why** (the specific assessment finding it derives from)
- **How to apply** (the trigger condition and the concrete action)

Plus a core operating instruction that is the synthesis itself: *here are my strengths, here are my documented gaps, supply exactly the gaps as a default, not on request.*

The two streams validated each other here. The assessment predicted a failure pattern. The growth log already had real instances of it. So the rule is not "personality theory says X." It is "the instrument predicts X, the work history confirms X, here is the trigger and the counter-move."

The framing that resonates with builders: this is encoding a methodology so it executes consistently instead of depending on the practitioner remembering to apply it. The operating manual is a collaboration methodology compiled to a spec with triggers.

### Phase 4: The durability test

Same day, unprompted, I did not trust that the work persisted. I asked the agent to surface exactly what was saved, where it lived, and whether it would actually load in a future session. I treated the written file as a claim to verify, not as proof that the calibration was real.

This phase is why it stuck. A calibration artifact that is written and never verified decays into a file nobody loads. The verification step converted it from a document into a live behavior.

### Phase 5: Continued enforcement

The pattern kept compounding. The same instinct (distrust an unverified artifact or an unmeasured loop) later forced other near-misses into hard rules in the project's top-level instructions, rather than leaving them as filed notes. The manual is not frozen. It is the current state of an accumulation that is still running.

---

## Why the fusion is the transferable lesson

- Build only **Stream A** (read your assessments) and you get accurate but inert self-knowledge the AI applies generically.
- Build only **Stream B** (log behavioral corrections) and you get sharp situational rules with no model of *why*, so the AI cannot generalize to a situation it has not seen yet.

Fused, the *why* comes from the instrument and the *trigger* comes from the observed incident. The AI can then catch a new instance of an old failure mode before it completes, because it knows both the structural cause and what the early signal looks like in practice.

That is the difference between an assistant that is less agreeable and a partner that closes your specific blind spots.

---

## How you build your own

The architecture copies exactly. The content does not. Using someone else's manual would calibrate the AI to *their* gaps, which for you is worse than no calibration.

1. **Seed the preference (Stream B, start now).** State plainly how you want to be challenged and let it become a feedback memory. This is Phase 0. Do not stop here.
2. **Run the log (Stream B, ongoing).** Capture one behavioral observation per working session. Capture failures especially, and capture validated judgment calls so it does not drift cautious. Let this run a few weeks before Phase 2. The accumulation needs real incidents to fuse against.
3. **Get raw assessment data (Stream A).** Clifton, SDI, an Enneagram instrument with depth, Big Five. Instruments matter less than having real structured data including your weaknesses.
4. **Read it raw, not summarized.** Have the AI read the actual reports. Hand it a flattering self-summary and you lose the entire value, because the value is in the parts you would not have written down.
5. **Synthesize with the three-part structure.** Every rule gets a rule, a why anchored to a specific finding, and a how-to-apply with a trigger. Force each assessment finding to meet a real incident from your log. Where they agree, that is a high-confidence rule. Where the assessment predicts something your log has never shown, mark it a watch item, not a hard rule.
6. **Test durability the same day.** Make the AI surface what it saved, where, and prove it loads in a fresh session. An unverified calibration file is not calibration.
7. **Keep it running.** Every later correction either sharpens an existing rule or adds one. It is never finished.

---

## The four ways to build a weak one

- **Summarizing the assessments instead of reading them raw.** You filter out exactly the findings that have value.
- **Only logging corrections, never failures or validated wins.** Corrections alone make the AI timid. The strongest rule in mine came from a real money-losing mistake, not a style note.
- **Writing it once and trusting it.** Unverified, it decays into an unloaded file. The durability test is not optional.
- **Copying someone else's manual.** It will competently apply the wrong person's counterweights to your decisions.

One-line version: the operating manual works because a multi-year stack of psychometric data was forced to meet a few weeks of real incident logs on a single day, then verified to actually load. **Reproduce the process. Do not reuse the contents.**
