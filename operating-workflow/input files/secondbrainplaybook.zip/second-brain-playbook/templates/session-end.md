---
name: session-end
description: End-of-session capture. Writes a handoff, updates CLAUDE.md current state, flags what's blocked or pending.
triggers:
  - "session end"
  - "end session"
  - "wrap up"
  - "i'm done for now"
  - "let's close out"
  - "done for today"
---

# session-end Skill

## Purpose
The next session should start fast. This skill writes the handoff so future-you does not have to reconstruct what happened. Takes 2 minutes. Saves 10.

## Steps

1. Ask (if not obvious): "What did you finish this session? Any blockers?"
2. Write `.claude/handoff.md` with:
   - What was worked on (2-3 bullets)
   - What was completed (mark done)
   - What is in progress (carry forward)
   - Any blockers or waiting-on-someone items
   - Suggested first action for next session

3. Update CLAUDE.md ## Current State section (2-3 sentences, present tense)
   - What is the current status of the main project/task
   - What is blocked or pending

4. If anything worth preserving long-term (a decision, a design choice, a lesson), ask:
   "Anything worth capturing to your vault? One line is enough."

## handoff.md format

```markdown
# Handoff: [date]

## Done this session
- [what was completed]

## In progress
- [what is partially done]

## Pending / blocked
- [what's waiting on something or someone]

## Next session: start here
[one specific, concrete first action]
```

## Rules

- Never summarize the whole project. Only what changed this session.
- Never file anything to the vault without asking.
- Never commit code. That is not this skill's job.
- Keep handoff.md under 20 lines. If it is longer, summarize.
