# Hermes Translation: Proven → Verify

The architecture in this playbook is **proven on Claude Code.** The exact wiring below is what you translate to Hermes and **verify on your own machine.** This file is the honest bridge between the two. Nothing here is hand-waved: each row is tagged.

- ✅ **PROVEN**: I run this daily on Claude Code; it works exactly as described.
- 🔶 **TRANSLATE**: same idea, different mechanics on Hermes; verify the specifics yourself.

---

## The three moves (this is the whole job)

The talk ends on three moves. Here they are as a checklist.

### Move 1: Give your agent the folder

✅ **PROVEN (Claude Code):** A vault is just a folder of markdown on your machine. Claude Code has direct read/write file access, so you point it at the vault directory and it works. No API, no server.

🔶 **TRANSLATE (Hermes):** The principle is identical: same-machine filesystem access to the vault folder is the entire trick. What you verify on Hermes:

- [ ] Does your Hermes agent run on the **same machine** where Obsidian / the vault folder lives? (It must. A remote agent cannot read a local vault: there is no powered-off API for an Obsidian vault.)
- [ ] Can Hermes **read** a file in the vault folder? Test with one file.
- [ ] Can Hermes **write** a file into the vault folder? Test by having it create `00-Inbox/test.md`.
- [ ] Can Hermes **search** across the folder (grep/glob equivalent)?

If all four pass, Move 1 is done. If your Hermes runs in a sandbox or a different host than the vault, solve that first: everything else depends on it.

### Move 2: Mirror the taxonomy

✅ **PROVEN:** Every wall uses the identical folder structure (`00-Inbox`, `01-Projects`, `04-Knowledge`, `09-Meetings`, …). The agent is taught this shape **once**, as a rule, and never guesses where a note goes.

🔶 **TRANSLATE:** Teaching "the rule" is where the tools differ.

- On Claude Code the rule lives in `CLAUDE.md` + the per-vault `_Claude-Bridge.md` index.
- On Hermes, put the same rule wherever Hermes loads its persistent instructions / system context, and keep a `_Vault-Bridge.md` index file in each wall that the agent is told to read first.
- [ ] Confirm Hermes actually **loads** that instruction every session (not just once). If it forgets the taxonomy between sessions, the routing breaks.

### Move 3: Add skills per context

✅ **PROVEN:** Wrap your real workflows as named skills, each fenced to one wall. Start with `capture` and a daily standup. Grow only what you use.

🔶 **TRANSLATE:** "Skill" means different things across tools.

- On Claude Code a skill is a `.claude/skills/{name}/SKILL.md` file invoked with `/name`.
- On Hermes, use Hermes' own equivalent for a named, repeatable instruction set (a saved workflow / command / routine: verify the exact term and mechanism in your Hermes docs). The **content** of the templates in this playbook ports directly; only the wrapper changes.
- [ ] Recreate `capture` and `morning-standup` first. Confirm each is invocable by a short phrase and produces the same output the template describes.

---

## Concept-by-concept map

| Concept | Claude Code (✅ proven) | Hermes (🔶 verify) |
|---|---|---|
| Agent ↔ vault | Direct filesystem read/write | Same-machine file access: confirm the agent can read/write the folder |
| Per-vault index | `_Claude-Bridge.md`, read first | `_Vault-Bridge.md`, told to read first |
| Global rules | `CLAUDE.md` (kept < 3KB) | Hermes' persistent-instruction surface |
| Routing rules | `.claude/rules/{name}.md`, loaded on trigger | Wherever Hermes loads conditional context |
| Memory index | `MEMORY.md` loaded every session | Hermes memory + a markdown index it reads at start |
| A skill | `.claude/skills/{name}/SKILL.md`, `/name` | Hermes saved workflow / routine |
| Automation | system cron / OpenClaw | Hermes' own scheduler (it has one): see `SKILL-AND-CRON.md` |

---

## What does NOT need translating

These are agent-agnostic. They work the same no matter what runs them, because they are just files and folders:

- The **vault** itself (Obsidian, the folder of markdown).
- The **taxonomy** (`vault-skeleton/`).
- The **walls** (separate vaults for isolation).
- **FOCUS.md**, **MEMORY.md**, the **bridge** files.
- The **content** of every skill template (the instructions; only the wrapper format changes).
- Obsidian **Sync** for sharing a wall with another person.

So most of this playbook is portable as-is. The translation surface is small: *how the agent gets file access, where it loads its rules, and how it saves a named workflow.* Three things. Verify those three and the rest just works.

---

## A note on memory tools (G-Brain, Mem0, Honcho, Hermes memory)

Do not rip these out. They are the conversation-memory layer (strongest at working memory + cross-session recall). The Obsidian second brain is the **knowledge-and-work** layer you browse yourself. Run both. The README's closing section covers why.

---

## If you get stuck

The failure is almost always Move 1: the agent and the vault are not on the same machine, or the agent lacks write permission to the folder. Re-test the four checkboxes in Move 1 before touching anything else. Everything downstream assumes the agent can read and write the vault folder.
