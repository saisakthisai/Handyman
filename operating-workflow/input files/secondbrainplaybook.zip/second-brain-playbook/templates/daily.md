---
name: daily
description: End-of-day wrap. What moved, what didn't, tomorrow's anchor. Reads handoff and FOCUS. Takes 3 minutes.
triggers:
  - "/daily"
  - "end of day"
  - "day wrap"
  - "wrap the day"
  - "close out the day"
  - "what did I do today"
---

# daily Skill

## Purpose
Before you close the laptop, spend 3 minutes on this. Tomorrow-you will know exactly where to start. Without it, you spend 15 minutes reconstructing.

## Files to read (only 2)
1. `.claude/handoff.md`: what was in progress
2. `YOUR_VAULT_PATH/FOCUS.md`: weekly priorities and inbox

No other reads. CLAUDE.md is already loaded.

## Steps

1. Ask (if the day's work is not obvious from handoff): "What did you work on today? Any wins or blockers?"
2. Generate the daily wrap output.
3. Ask: "Anything worth saving to your vault before you close?" If yes, write it. If no, done.

## Output

```
DAY WRAP: [date]

WHAT MOVED:
- [thing that actually advanced today]
- [another thing]

WHAT DIDN'T (and why):
- [thing that was planned but didn't happen]: [one-word reason: blocked / deprioritized / took longer]

TOMORROW'S ANCHOR:
[one specific first action for tomorrow: not a list, just one thing]

WEEKLY PRIORITY CHECK:
[Are you on track for your top 3 this week? One sentence.]
```

## Vault capture (ask before writing)

If the user worked through something non-obvious today (a debugging insight, an architectural decision, a lesson), ask:

"Anything worth a one-liner in your vault?"

If yes: append to `YOUR_VAULT_PATH/00-Inbox/[today's date]-captures.md`
If no: close out.

## Rules

- Never write to the vault without asking first.
- Keep the output under 15 lines. If there's more, summarize.
- Tomorrow's anchor is ONE thing. Not a list.
- If nothing moved today, say so plainly. No softening.
