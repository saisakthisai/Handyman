---
name: strategic-lenses
description: Apply a named toolkit of strategic decision lenses to any artifact, decision, or claim. All 10 lenses or a named subset. Mandatory Executor close (one concrete next step) on multi-lens runs. Use when you say "use the strategic lenses", "run the lenses on this", or name a specific lens ("steelman this", "red team this", "invert this", "pre-mortem this", etc.).
argument-hint: "[artifact, decision, or question to analyze] [optional: lens names or 'all']"
triggers:
  - "use the strategic lenses"
  - "run the lenses"
  - "apply the lenses"
  - "use all lenses"
  - "steelman this"
  - "red team this"
  - "invert this"
  - "pre-mortem this"
  - "first principles this"
  - "five whys"
  - "outsider lens"
  - "falsify this"
  - "anti-positioning"
  - "jobs to be done"
---

# strategic-lenses

Apply a named decision and research toolkit to stress-test any artifact, decision, or claim before acting on it.

## The 10 Lenses (canonical)

1. **First Principles**: strip to irreducible truths. What do we actually know vs. assume? Rebuild from foundations.
2. **Inversion**: what would guarantee failure here? Avoid that. (Munger.)
3. **Jobs-to-be-Done (JTBD)**: what is the buyer/user actually hiring this for? Functional, emotional, social.
4. **Five Whys**: drill from symptom to root cause. Don't stop at the first plausible answer.
5. **Falsifiability**: what evidence would prove this wrong? If nothing could, it is not a claim, it is a vibe.
6. **Anti-positioning**: what are we deliberately NOT? Differentiation lives in what we don't promise.
7. **Pre-mortem**: fast-forward 6-12 months: this failed. Why? Surface failure modes before they happen.
8. **Steelman**: make the strongest possible case for the opposing view before arguing against it.
9. **Red Team**: adversarial review. What would a hostile competitor, skeptical buyer, or journalist tear apart first?
10. **Outsider**: pretend zero industry context. Would a non-expert still find this important, valuable, or compelling?

## When to invoke

- You type `/strategic-lenses [artifact]` → run all 10
- You name a specific lens: "steelman this", "red team this", "invert this" → run that lens only, deep
- You list a subset: "run first principles and pre-mortem on this" → run those lenses only
- You apply one lens across multiple items: "run five whys on all my stalled projects" → Mode D
- Mid-conversation you say "use the strategic lenses" about something already in context → the artifact is the most recent thing discussed

## Parsing $ARGUMENTS

1. If `$ARGUMENTS` contains a lens name (or alias), mode = **specific lens(es)**
2. If `$ARGUMENTS` says "all" or no lens names, mode = **all lenses**
3. If `$ARGUMENTS` is empty and the trigger named a lens (e.g. "steelman this"), extract the artifact from conversation context
4. If `$ARGUMENTS` says "applicable", "relevant", "any that fit", or "whichever apply", mode = **agent-selected subset** (Mode E)

**Lens aliases** (trigger → canonical name):
- "steelman" → Steelman
- "red team" / "adversarial" → Red Team
- "invert" / "inversion" / "flip it" → Inversion
- "first principles" / "first-principles" → First Principles
- "five whys" / "5 whys" → Five Whys
- "falsify" / "falsifiability" → Falsifiability
- "anti-positioning" / "what are we not" → Anti-positioning
- "pre-mortem" / "premortem" → Pre-mortem
- "JTBD" / "jobs to be done" / "jobs-to-be-done" → JTBD
- "outsider" / "non-expert" → Outsider

## Execution

### Mode A: All lenses

Run each lens against the artifact in order (1-10). For each:
```
**[Lens Name]**
[What this lens surfaces about the artifact. 2-5 sentences, concrete, no padding.]
[If this lens yields nothing meaningful, say so explicitly: "Yields nothing here: [brief reason]."]
```

After all 10, mandatory Executor close:
```
**Executor close**
[One concrete next step. No analysis exits without an action. Single sentence, starts with a verb.]
```

### Mode B: Specific lens (one named)

Go deep on that single lens. 3-8 sentences. Specific findings, not generic descriptions of what the lens does. If the lens yields nothing, say so and explain why. No Executor close required for single-lens runs (optional if asked).

### Mode C: Named subset

Run each named lens in order. Executor close mandatory if 3 or more lenses were applied.

### Mode D: Single lens, multiple artifacts

Triggered when you say "run [lens] on all my [projects/items/decisions]" or provide a list rather than a single artifact.

1. Extract the item list from context, or ask for it if not visible.
2. Triage first: separate items that are genuinely stalled from items on the correct schedule. State this triage explicitly before running the lens.
3. Apply the named lens to each stalled item in sequence:
   - State the item name as a subheader
   - Run the full chain (do not truncate)
   - End each item with one line: root cause type
4. After all items, add a cross-artifact synthesis: "Common pattern: [what root cause appears most and what that implies]"
5. Executor close: one action that addresses the most common root cause across the set.

### Mode E: Agent-selected subset

Triggered when you ask for "applicable" / "relevant" / "whichever fit" lenses without naming them.

1. State up front which lenses you are running and which you are skipping, one line each, with a one-clause reason for each skip. This makes the selection auditable instead of silent.
2. Run the selected lenses in canonical order (1-10).
3. A lens you considered but that yields nothing is a skip with a reason, not a forced finding.
4. Executor close mandatory (this mode always applies 3+ lenses).

## Quality rules

- A lens that yields nothing on a given artifact is a finding, not a failure. Say so explicitly ("Yields nothing here") rather than forcing one.
- Never describe what a lens is: apply it. The output should be findings, not definitions.
- No em-dashes. No filler jargon ("table stakes", "north star", "move the needle", "leverage"). Max one "X not Y" construction per document; rephrase the rest as direct positives.
- If the artifact is scoped to one context (one company, one project), apply the lens within that context. If it is cross-cutting, say which context each finding applies to.

## Output format

```
STRATEGIC LENS ANALYSIS
Artifact: [one-line description of what was analyzed]
Mode: [All 10 / Specific: {lens name} / Subset: {lens names}]

---

**[Lens 1 name]**
[findings]

**[Lens 2 name]**
[findings]

...

**Executor close**
[one concrete next step]
```

Keep the header tight. No preamble. Jump straight to the output.
