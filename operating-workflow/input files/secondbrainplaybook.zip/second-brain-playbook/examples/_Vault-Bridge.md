# _Vault-Bridge: [Your Vault Name]

This file is the index of your Obsidian vault. Your agent reads this first, then reads only the 1-2 files it actually needs. It never scans the full vault.

**Update this file whenever you add a meaningful note to the vault.**

> Naming note: on Claude Code this is conventionally `_Claude-Bridge.md`. On Hermes or any other agent, the filename does not matter: what matters is that your agent is told to read this index first. Keep one bridge file per vault (per "wall").

---

## Active Projects
- `01-Projects/[project-name]-spec.md`: Spec and status for [project]
- `01-Projects/[project-name]-spec.md`: Spec and status for [project]

## Knowledge Base
- `04-Knowledge/[topic].md`: [one-line description of what's in this file]
- `04-Knowledge/[topic].md`: [one-line description]

## People
- `02-People/[name].md`: [who they are, context, open threads]

## Meetings & Calls
- `09-Meetings/[name]/[date]-[topic].md`: [one-line: who, what was decided]

## Content
- `05-Content/[title].md`: [draft or post in progress]

## Products
- `12-Products/[product]/[note].md`: [one-line description]

---

## Bridge file rules

1. One line per note. Format: `path/to/file.md: what is in this file`
2. Only include notes your agent might need. Not every note.
3. Update this when you add important notes. It does not need to be perfect.
4. If your agent asks for a file not in this bridge, it probably does not need it.

The goal: the agent reads this bridge (small), picks 1-2 files, and stops. It never scans the full vault.
