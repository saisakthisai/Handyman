# Week of [Date]

## Top 3 this week
1. [highest leverage item: be specific about what "done" looks like]
2. [second priority]
3. [third priority]

## Waiting on (not yours to chase this week)
- [Person]: [what you need from them]

## Intentionally deferred
- [things you decided not to do this week and why]

## Inbox (captured items, not yet prioritized)
- [thing captured mid-session]
- [another thing]

## Ideas (not tasks yet)
- [thought worth keeping but not acting on now]

## Ask [Name] (things to bring up in a conversation)
- [question or topic to raise]

---

## How to use this file

Update the Top 3 every Monday. Takes 5 minutes.
The rest (Inbox, Ideas, Ask) gets added throughout the week via `capture: [thing]`.

Morning standup reads the Top 3 and gives you today's anchor.
At week-review, everything in Inbox gets triaged to next week's Top 3 or dropped.
