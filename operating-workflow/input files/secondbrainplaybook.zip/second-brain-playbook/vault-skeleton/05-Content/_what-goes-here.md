# 05-Content

Drafts, posts, and outputs in progress.

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
