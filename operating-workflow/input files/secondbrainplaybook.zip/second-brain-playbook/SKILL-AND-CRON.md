# Write Your Own Skills + Automate Them

Two parts: how to write a new skill from scratch, and how to run skills on a schedule. Both apply whether you run Claude Code or Hermes: where the mechanics differ, it is called out.

---

## Part 1: Creating your own skills

### The short answer

You cannot use someone else's skill directly if it is wired to their accounts, paths, or setup. The **structure** is the same; the **content** is yours to write. A skill is just a markdown file (or a saved workflow) that tells your agent: *"when I say X, do Y, in this format, with these rules."* No code. Plain English.

### The skill format

On Claude Code, every skill lives at `.claude/skills/{name}/SKILL.md`:

```markdown
---
name: skill-name
description: One line: what this skill does
triggers:
  - "phrase that activates this"
---

# skill-name

## Purpose
Why this skill exists. What problem it solves.

## Files to read
The files the agent should read (3 max).

## Steps
1. Do this first
2. Then this
3. Output in this format

## Output
The exact output format you want.

## Rules
- Hard constraints the agent must follow
- Things it must never do
```

On **Hermes**, the same five blocks (purpose / files / steps / output / rules) go into Hermes' saved-workflow mechanism. The wrapper differs; the content is identical.

### The prompt to give your agent

```
I want to create a new skill. Write the skill file for me.

SKILL NAME: [name: dashes, no spaces, e.g. inbox-triage]
WHAT IT DOES: [plain English]
WHEN I INVOKE IT: [what I type: e.g. "/inbox-triage" or "triage my inbox"]
FILES IT SHOULD READ: [list, or "ask me"]
OUTPUT FORMAT: [what I want to see]
HARD RULES: [what it must never do]
MY VAULT PATH: [your path]

Write the complete skill file. Ask any clarifying questions before saving.
Once I approve, save it to the right location.
```

### Tips for good skills

- **Be specific about the output format.** Agents match a shown template exactly.
- **One rule per constraint.** "Never do X" beats "be careful about X."
- **Start minimal.** One thing, done well. Add complexity once it works.
- **Test on a small example** before running it on everything.
- **When it does something wrong, add a rule.** The skill is a living document.

---

## Part 2: Running skills on a schedule

Start manual. Run skills by hand for 2-3 weeks. Automate only what you find yourself doing at the same time every day without thinking.

### What to automate first (and what to leave manual)

**Good first automations** (low risk, read-only):
- Morning brief delivered to a file or chat before you open your laptop
- A Friday reminder to run `week-review`
- An end-of-day log entry

**Leave manual for now:**
- Inbox triage (needs your approval before acting)
- Anything that sends messages or modifies files unattended
- Anything that costs money per run

**The rule:** only automate what you have already run manually 10+ times and know works exactly as expected.

### Option A: Hermes' own scheduler

Hermes has a built-in scheduler/cron. This is the natural choice for Hermes users: define the schedule, point it at the workflow, and let it deliver to your chat channel. Verify in your Hermes docs:

- [ ] How to register a scheduled job and its time (note the timezone: see below).
- [ ] That a **scheduled** fire actually runs (test the schedule, not just a manual run: they can behave differently).
- [ ] Where output is delivered (channel / file).

### Option B: System cron (Claude Code, Mac/Linux/WSL)

Runs the agent non-interactively on a schedule.

**1. Confirm print mode:**
```bash
claude --help | grep -i print
```
If you see `--print` / `-p`:
```bash
claude -p "good morning" --output-format text
```

**2. A script** at `~/scripts/morning-brief.sh`:
```bash
#!/bin/bash
cd /path/to/your/working-directory
claude -p "good morning" --output-format text >> ~/logs/morning-brief.log 2>&1
```
```bash
chmod +x ~/scripts/morning-brief.sh
```

**3. Add to crontab** (`crontab -e`): 8am every weekday:
```
0 8 * * 1-5 /bin/bash /Users/you/scripts/morning-brief.sh
```

### Option C: Cron + chat webhook (delivers to your phone)

To send output to Slack/Telegram instead of a log file, capture it and POST to an incoming webhook:
```bash
OUTPUT=$(claude -p "good morning" --output-format text 2>&1)
curl -s -X POST -H 'Content-type: application/json' \
  --data "{\"text\": \"$OUTPUT\"}" \
  YOUR_WEBHOOK_URL
```

### Cron time reference

```
*  *  *  *  *
│  │  │  │  └── day of week (0=Sun … 6=Sat)
│  │  │  └───── month (1-12)
│  │  └──────── day of month (1-31)
│  └─────────── hour (0-23)
└───────────── minute (0-59)

0 8 * * 1-5   weekdays 8:00am      0 9 * * 1   Mondays 9:00am
0 17 * * 5    Fridays 5:00pm       0 8 * * *   every day 8:00am
```

**Timezone gotcha:** most cron systems run in **UTC**. If you want 8am local, convert. IST (UTC+5:30) 8am → `30 2 * * *`. And some systems silently ignore a `CRON_TZ` setting: always write the time in UTC and note your local time in a comment.

---

## The principle for both parts

There is **no technical wiring** between skills. They are connected by **you**, through how you work: the morning standup names the 3 things, you call the skill each thing needs, you capture as you go, session-end writes the handoff, tomorrow's session-start reads it. The flow is human-driven. Automation is a thin layer you add on top **after** the manual rhythm is solid: never before.
