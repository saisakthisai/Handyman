# 01-Projects

One file per active build: spec, status, decisions.

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
