# 09-Meetings

Call notes, one subfolder per person: 09-Meetings/{name}/{date}-{topic}.md

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
