# 00-Inbox

Longer raw notes and brain-dumps land here, unsorted. (Quick one-line 'capture:' items go to FOCUS.md's inbox, not this folder.) Triage later.

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
