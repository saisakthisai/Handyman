# 12-Products

What you ship. One folder per product.

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
