---
name: capture
description: Fire-and-forget idea capture mid-session. Say "capture: [thing]" and it routes instantly without breaking your flow.
triggers:
  - "capture:"
  - "capture this"
  - "log this"
  - "note this"
  - "don't let me forget"
  - "jot this down"
---

# capture Skill

## Purpose
Something popped into your head mid-session. Say "capture: [thing]" and it is gone: routed, acknowledged, done. Back to work in 5 seconds.

## Routing Rules

| What it sounds like | Route to |
|---------------------|----------|
| Task I need to do | `FOCUS.md ## Inbox` |
| Ask someone | `FOCUS.md ## Ask [Name]` |
| Idea, not a task yet | `FOCUS.md ## Ideas` |
| Bug or issue to fix | `FOCUS.md ## Inbox` with `[bug]` prefix |
| Something to research | `FOCUS.md ## Inbox` with `[research]` prefix |
| Something to build later | `FOCUS.md ## Later` |

FOCUS.md path: YOUR_VAULT_PATH/FOCUS.md

## Steps

1. Parse the captured item. Which routing bucket fits?
2. Append to the correct section in FOCUS.md. Create the section if missing.
3. Confirm in one line: `Captured: "[item]" → FOCUS.md ## [Section]`
4. Return to the conversation immediately.

## Hard rules

- Never discuss or expand on the captured item.
- Never ask clarifying questions. Route using best judgment.
- Never read more than FOCUS.md. Write-only skill.
- One line of confirmation. Then stop.

## Example

Input: `capture: try codegraph for the auth module refactor`
Output: `Captured: "try codegraph for auth module refactor" → FOCUS.md ## Inbox`
