---
name: person-brief
description: Generates a sync-ready brief before a call or meeting with anyone. Pulls what's pending, what to tell them, suggested talking points.
triggers:
  - "prep me for [name]"
  - "person brief [name]"
  - "meeting prep [name]"
  - "brief me on [name]"
  - "what do I need before my call with [name]"
---

# person-brief Skill

## Purpose
Before any call or meeting, surface everything relevant in one screen. What they need to hear, what you need from them, what to decide together. No scrambling.

## Steps

### Step 1: Identify the person
Parse the name from the trigger. If unclear, ask.

### Step 2: Gather context (max 4 file reads)
- `YOUR_VAULT_PATH/FOCUS.md`: any sections mentioning them (e.g., "## Ask [Name]")
- `.claude/handoff.md`: any pending items involving them
- `YOUR_VAULT_PATH/_Vault-Bridge.md`: scan for shared project notes
- If a specific meeting note or project file exists for them, read that instead

### Step 3: Output

```
BRIEF FOR [NAME]: [date]

TELL THEM:
- [updates they need from you: be specific]

ASK THEM:
- [what you need from them: include enough context so they can actually answer]

DISCUSS (needs joint decision):
- [topics that need you both]

FYI (no action needed):
- [things they should know but do not need to respond to]

SUGGESTED TALKING ORDER:
1. [best opener: usually the most time-sensitive item]
2. [key decision to resolve]
3. [next steps to agree on]
```

## Rules
- Max 4 file reads total
- Be specific: "Ask about the API timeline for phase 2" not "discuss the project"
- If nothing is pending with this person, say so: that is useful information too
- Do not fabricate context. If something is not in the files, say "nothing found: add context manually"
- Keep the whole brief under 20 lines
