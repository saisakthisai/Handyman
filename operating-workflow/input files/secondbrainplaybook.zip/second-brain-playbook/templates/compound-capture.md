---
name: compound-capture
description: Capture learnings from any debugging or problem-solving session. Stores structured solutions so the same problem is never solved twice.
triggers:
  - "/compound-capture"
  - "capture this learning"
  - "save this solution"
  - "log what we figured out"
  - "don't want to lose this"
---

# compound-capture Skill

## Purpose
After debugging, troubleshooting, or solving anything non-obvious, extract the reusable learning and store it. Future-you starts smarter. You never explain the same root cause twice.

## Steps

### Step 0: Check for duplicates
Search `YOUR_VAULT_PATH/solutions/` for related notes. If something similar exists, offer to update it instead of creating a new one.

### Step 1: Identify what was solved
Review what just happened. What was the problem? What was tried? What fixed it?
Confirm with user before writing anything.

### Step 2: Classify
Pick the best category (or create one):
- `engineering`: code, architecture, implementation
- `debugging`: errors, root causes, fixes
- `tools`: CLI tools, APIs, integrations
- `deployment`: builds, containers, config
- `prompt-engineering`: Claude behavior, agent design
- `workflow`: process, habits, automation

### Step 3: Write the solution note
Create at `YOUR_VAULT_PATH/solutions/{category}/{slug}.md`:

```markdown
# {Short, searchable title}

**Date:** {YYYY-MM-DD}
**Category:** {category}
**Confidence:** high / medium / low

## Symptom
What did the problem look like from the outside?

## Root Cause
Why did it happen? (This matters more than the fix.)

## Solution
Specific steps that resolved it.

## Prevention
How to avoid this class of problem in the future.
```

### Step 4: Update the index
Append one line to `YOUR_VAULT_PATH/solutions/INDEX.md`:
```
- [{category}] [{title}]({category}/{slug}.md): {one sentence}
```
Create INDEX.md if it does not exist.

## Rules
- Keep each note under 40 lines
- Root cause is mandatory: do not write a note that only documents the fix
- Search before creating to avoid duplicates
- If confidence is low, say so: a low-confidence note is better than no note
