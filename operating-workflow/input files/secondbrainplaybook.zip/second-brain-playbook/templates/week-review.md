---
name: week-review
description: Friday synthesis. What shipped, what moved, what stalled, decisions made, priorities for next week.
triggers:
  - "week review"
  - "friday review"
  - "what happened this week"
  - "weekly wrap"
  - "wrap the week"
---

# week-review Skill

## Purpose
One weekly synthesis. What actually moved vs what was planned. The gap between the two is the most useful information you have.

## Files to read (max 3)
1. `YOUR_VAULT_PATH/FOCUS.md`: this week's planned priorities
2. `.claude/handoff.md`: last session's pending items
3. `YOUR_VAULT_PATH/_Vault-Bridge.md`: scan for any notes added this week

## Output

```
WEEK REVIEW: Week of [date]

SHIPPED / COMPLETED:
- [what was actually finished this week]

IN PROGRESS (carrying forward):
- [item + where it stands right now]

STALLED / BLOCKED:
- [item + what is blocking it]

DECISIONS MADE:
- [key choices locked in this week]

WHAT DID NOT HAPPEN (planned but didn't):
- [honest list: no softening]

NEXT WEEK: TOP 3:
1. [highest leverage item]
2. [second]
3. [third]
```

## After running
Update `YOUR_VAULT_PATH/FOCUS.md` with next week's Top 3. Replace the old ones: do not append.

## Rules
- Be honest about what did not happen. That is the most valuable part.
- Keep to 20 lines max. If there is more, group and summarize.
- If this is the first week-review, do it from memory. Do not skip because files are sparse.
