# 02-People

One note per person you work with: context, history, open threads.

_(Delete this note once you have real files here. It only exists so the empty folder ships in the playbook.)_
