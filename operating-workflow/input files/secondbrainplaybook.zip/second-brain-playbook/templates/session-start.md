---
name: session-start
description: Load only the context you need for this work block. Prevents loading everything. Max 4 file reads.
triggers:
  - "session start"
  - "start my session"
  - "let's get started"
  - "what are we working on"
  - "load context for"
  - "pick up where we left off"
---

# session-start Skill

## Purpose
You do not need all your context all the time. You need the context for what you are doing RIGHT NOW. This skill loads the minimum and asks what you need.

## Hard rule
Never read more than 4 files per session orientation.

## Cold start (no topic provided)

1. Read `.claude/handoff.md` (what was pending from last session)
2. Read `YOUR_VAULT_PATH/FOCUS.md` (weekly priorities, already know path)
3. CLAUDE.md is already loaded: do not read it again

Output:
```
SESSION ORIENTATION: [date]

LAST SESSION:
[1-2 lines from handoff.md: what was in progress, what was left]

PENDING:
[top 3-5 items from handoff.md]

WEEKLY PRIORITIES:
[top 3 from FOCUS.md]

What are you working on today?
```

## Topic-based start

When user says "session-start [topic]", load only what that topic needs.

### Engineering / building work:
Read (max 2 files): project spec or status note in vault → `YOUR_VAULT_PATH/01-Projects/{topic}.md`

### Research / learning:
Read (max 1 file): `YOUR_VAULT_PATH/04-Knowledge/{topic}.md` if it exists

### Admin / planning:
Read nothing extra. CLAUDE.md + FOCUS.md is enough.

## Output format after topic is known

1. One sentence: current state of this topic
2. What is in progress (2-3 bullets max)
3. Any blockers or decisions pending
4. Suggested first action for this session

Then stop. Wait for user to start.
