---
name: status
description: Scans all memory and handoff files for open questions, pending decisions, TODOs, and blockers. One prioritized list.
triggers:
  - "/status"
  - "what's pending"
  - "what's open"
  - "what do I have outstanding"
  - "what's blocking me"
  - "give me a status"
---

# status Skill

## Purpose
When you feel scattered or "where was I?", run this. One clean list of everything unresolved. Nothing hidden, nothing buried.

## Files to read (in order, stop when you have enough)
1. `.claude/handoff.md`: what was pending last session
2. `YOUR_VAULT_PATH/FOCUS.md`: weekly priorities and inbox
3. CLAUDE.md ## Current State: already loaded

Max 3 file reads total.

## Output format

```
STATUS: [date]

BLOCKED (needs you to act or decide):
- [item]: waiting on [what]

IN PROGRESS (active, no blocker):
- [item]: [where it stands]

INBOX (captured but not started):
- [item]

DECISIONS PENDING:
- [question that needs an answer before work can proceed]

SUGGESTED NEXT ACTION:
[one specific thing to work on now]
```

## Rules

- List only items that are OPEN. Do not show completed work.
- If there is nothing in a category, omit that heading.
- Keep it under 20 lines total. If more, group and summarize.
- Never look at vault knowledge files or old meeting notes. Only handoff, FOCUS, CLAUDE.
