# Vault Skeleton

Drop these folders into the root of your Obsidian vault. This is the identical
taxonomy every "wall" uses. If you run more than one context, create a separate
vault per context and copy this same skeleton into each.

The repetition is the feature: because the shape never changes, your agent never
has to guess where a note goes.

Each folder has a `_what-goes-here.md` note describing its purpose: delete those
once you have real files in place.
