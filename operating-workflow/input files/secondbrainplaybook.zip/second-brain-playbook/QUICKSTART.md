# Quick Start: A Working Second Brain in ~45 Minutes

Zero to a daily rhythm your agent can run. Read the PDF and `README.md` first for the *why*; this is the *how*.

---

## Before you start

You need:
- **Obsidian** installed, with at least one vault.
- **An AI agent on the same machine** as that vault, with file read/write access to the vault folder.
  - **Claude Code** (the proven reference): `claude` works in your terminal.
  - **Hermes**: works too; first complete Move 1 in `HERMES-TRANSLATION.md` to confirm file access, then follow the same steps, substituting Hermes' skill/workflow wrapper.

You do **not** need: a VPS, n8n, a database, a dashboard, or any coding experience.

> Throughout, replace `YOUR_VAULT_PATH` with your real vault path.
> Mac: `/Users/you/Documents/Vaults/YourVault`  ·  Windows (WSL): `/mnt/c/Users/you/Documents/Vaults/YourVault`

---

## Step 1: Build the vault skeleton (5 min)

Copy the `vault-skeleton/` folders from this playbook into your Obsidian vault. You get the identical taxonomy every wall uses:

```
00-Inbox  01-Projects  02-People  04-Knowledge  05-Content  09-Meetings  12-Products
```

If you run more than one context (e.g. two companies), make a **separate vault per context** ("a wall") and drop the same skeleton into each. Same shape every time: that is what makes routing automatic.

---

## Step 2: Create FOCUS.md (5 min)

Create `FOCUS.md` at the **root** of your vault, using `examples/FOCUS.md` as the template. Fill in your real top 3 for this week, and be specific about what "done" looks like.

This is the single most important file. Everything reads from here.

---

## Step 3: Create the bridge index (5 min)

Create `_Vault-Bridge.md` at the root of your vault, using `examples/_Vault-Bridge.md`. List only the files your agent might actually need: one line each. The agent reads this first and never scans the whole vault.

---

## Step 4: Install 2 starter skills (10 min)

Start with exactly two: **capture** and **morning-standup**. Two is enough to feel the rhythm.

**Claude Code:**
```bash
mkdir -p .claude/skills/capture .claude/skills/morning-standup
```
Copy `templates/capture.md` → `.claude/skills/capture/SKILL.md`
Copy `templates/morning-standup.md` → `.claude/skills/morning-standup/SKILL.md`
Replace every `YOUR_VAULT_PATH` in both files with your real vault path.

**Hermes:** create the same two workflows using Hermes' saved-workflow mechanism. Paste the **body** of each template as the instruction set; keep the same trigger phrases (`capture: ...`, `good morning`). The template bodies mention `CLAUDE.md` and `.claude/handoff.md` (Claude Code names): map those to Hermes' equivalents per `HERMES-TRANSLATION.md` Move 3.

> Fast path (Claude Code only): paste `BOOTSTRAP-PROMPT` below into a fresh session and it installs everything for you.

---

## Step 5: Point your agent's rules at the vault (10 min)

Your agent needs three facts in its persistent instructions:

1. Where the vault is (`YOUR_VAULT_PATH`).
2. The taxonomy rule: *quick `capture:` one-liners → `FOCUS.md` inbox, longer notes → `00-Inbox`, meetings → `09-Meetings`, durable knowledge → `04-Knowledge`* (etc).
3. To read `_Vault-Bridge.md` first, then only the 1-2 files it needs.

- **Claude Code:** put these in `CLAUDE.md` (see `examples/CLAUDE.md`). Keep it under 3KB.
- **Hermes:** put the same three facts wherever Hermes loads persistent context, and confirm it reloads them each session.

---

## Step 6: Test it (5 min)

Open a fresh agent session in your working directory.

**Test 1: Morning standup.** Say: `good morning`
→ It should read `FOCUS.md` and give you today's 3 priorities.

**Test 2: Capture.** Say: `capture: test item from setup`
→ It should route the item and confirm. Open `FOCUS.md` and confirm the line landed under `## Inbox`. (Quick one-liners go to `FOCUS.md`, not the `00-Inbox` folder: see "Two inboxes" in the README.)

If both work, the system is live.

**If Test 1 fails:** check that `FOCUS.md` exists at your vault path and that the path in the skill/rules is correct.
**If Test 2 fails (Hermes):** re-run Move 1's write test in `HERMES-TRANSLATION.md`: the agent probably cannot write to the folder.

---

## The daily rhythm (what to actually do)

| When | Say / run | What it does |
|------|-----------|-------------|
| Every morning | `good morning` | 3 priorities for the day |
| Start of a block | `session-start` | Load context, see the handoff |
| Mid-session idea | `capture: [thing]` | Route it, back to work |
| End of a block | `session-end` | Write the handoff, update state |
| End of day | `daily` | What moved, tomorrow's anchor |
| Feeling scattered | `status` | Everything open, one view |
| Before a call | `person-brief [name]` | Sync-ready brief in 30 seconds |
| After debugging | `compound-capture` | Save the learning |
| Every Friday | `week-review` | Honest weekly synthesis |
| Every Monday | update `FOCUS.md` | New top 3 |

Install the rest of the templates (`session-start`, `session-end`, `status`, `daily`, `week-review`, `person-brief`, `compound-capture`) the same way as Step 4, when you reach that work. Don't install everything at once: grow only what you use.

**Bonus skills** (`bonus-skills/`): `strategic-partner` and `strategic-lenses` install the same way (copy to `.claude/skills/{name}/SKILL.md`). They put the thought-partner behavior on demand. Read `THOUGHT-PARTNER-CALIBRATION.md` and `OPERATING-MANUAL-CASE-STUDY.md` first for what they're for.

---

## The one question to ask yourself

Every time you feel the urge to add more (a dashboard, a database, more connections):

**"Does this help me do the work, or is it a way of avoiding the work?"**

This system is deliberately boring. It works because of that.

---

## Appendix: Bootstrap prompt (Claude Code only)

Paste into a fresh Claude Code session running from your working directory, with this playbook folder unzipped alongside it. (Hermes users: follow Steps 1-6 manually.)

```
I want to set up my second-brain operating system. The playbook folder is in my
current working directory at ./second-brain-playbook/

MY VAULT PATH: [FILL IN]
MY NAME: [FILL IN]

Complete every step in sequence, confirming each before the next. Use MY VAULT PATH
and MY NAME wherever a placeholder appears: do not ask me again.

STEP 1  Create folders: .claude/skills/{morning-standup,session-start,session-end,
        capture,status,daily,week-review,compound-capture,person-brief} and .claude/rules
STEP 2  For each template in ./second-brain-playbook/templates/, read it, replace every
        YOUR_VAULT_PATH with MY VAULT PATH, and write it to
        .claude/skills/{name}/SKILL.md
STEP 3  If MY VAULT PATH/FOCUS.md does not exist, create it from
        ./second-brain-playbook/examples/FOCUS.md. Do not overwrite if it exists.
STEP 4  If MY VAULT PATH/_Vault-Bridge.md does not exist, create it from
        ./second-brain-playbook/examples/_Vault-Bridge.md. Do not overwrite if it exists.
STEP 5  Copy the vault-skeleton folders into MY VAULT PATH if they are not there.
STEP 6  Create .claude/handoff.md containing "# Handoff\nNo previous session."
STEP 7  List every file created or skipped, tell me what to fill in manually, and end
        with: "Setup complete. Type 'good morning' to test."
```
