# Building a Calibrated AI Thought Partner

The second brain (the rest of this playbook) gives your agent a place to read your world from. This doc is the other half: how to turn that agent into a **calibrated counterweight to your own thinking**, one that remembers you across sessions, knows where you reliably go wrong, and is structurally set up to push back instead of agree.

From Renuka. This is the actual system I run on Claude Code. The coding capability is the easy part; the thought-partner quality is a separate system layered on top. Here is how to build your own.

> Honesty, same as everywhere in this playbook: proven on Claude Code. The architecture ports to Hermes; verify the file/memory mechanics on your machine (see `HERMES-TRANSLATION.md`).

---

## Part 1: The philosophy (read this first, it is the actual product)

### The counterweight principle

Most people prompt an AI for answers. The frame here is different. The AI is set up to be the part of the thinking you do not do well on your own.

Everyone brings a profile: some mix of energy, conviction, pattern-spotting, diagnostic instinct, structure, follow-through, patience. And everyone has documented gaps. The AI is configured to supply exactly the gaps, and to do it as a **default behavior, not on request.**

That asymmetry is the entire value. A tool that agrees with you doubles your blind spots. A counterweight calibrated to your specific gaps closes them. Generic "be helpful" produces the first. This setup is engineered to produce the second.

### The three mechanisms that make it work

**1. Memory.** A thought partner that forgets everything every session is not a thought partner. You need a file-based memory that persists across sessions: who you are, how you work, every correction you have given, the context behind current work. The agent reads it at session start and writes to it at session end. Without persistence, calibration cannot accumulate.

**2. Calibration.** This is the keystone and the part nobody does. You feed it real personality-assessment data and translate each finding into a specific counterweight behavior with a trigger condition. Not "I am a 7 on the Enneagram." Instead, a concrete rule like: *"when I describe a setback and jump straight to what I learned, stop me and ask what it actually cost"* (illustrative; yours come from your own profile). The behavior is the unit, not the label.

**3. Compounding feedback.** Every correction you give becomes a permanent behavior change stored in its own memory file. Every validated judgment call gets saved too, so the system does not drift back toward generic. Months of corrections compound into an agent that behaves measurably differently from a fresh one.

### The prerequisite most people skip

You cannot calibrate an AI to be your counterweight until you know your own gaps with precision. Vague self-knowledge produces vague calibration. This works because the calibration is built from formal assessment data, read directly, translated into behavioral rules with triggers.

This is the part that does not copy. You cannot use someone else's operating manual. The **architecture** replicates; the **contents** are personal and specific to your own profile.

---

## Part 2: How it actually got built (the honest progression)

It was not designed up front. It accumulated through experimentation across many sessions. The real order:

**Layer 0: Baseline config.** A `CLAUDE.md` at the project root and a global one. Infrastructure facts, hard rules, operating constraints. This is where most people stop. At this layer the AI is a competent assistant with project context. It is not yet a thought partner.

**Layer 1: Memory system.** A structured, file-based memory store with a typed schema (user facts, feedback, project state, references) and an always-loaded index. Two skills maintain it: one loads the minimum relevant set at session start, one writes observations at session end. This is the layer that makes everything after it persist.

**Layer 2: Personality calibration (the inflection point).** Read your assessment results directly. Do not summarize them into "your strengths." Extract the load-bearing findings, including the unflattering ones, and write an operating manual: a set of rules, each with a *why* (the assessment finding) and a *how to apply* (the trigger and the action). State explicitly that this governs how you collaborate, not just how output gets written. This is the layer people feel. Everything before it is good tooling. This is what makes it a thought partner.

**Layer 3: Compounding behavioral feedback.** Over subsequent sessions, every correction becomes a discrete memory file. (Examples from mine: no em-dashes; do not be a yes-machine; confirm cost before any paid API call; phase work with gates instead of cramming; latest version of a doc goes on top.) Each one is permanent and loads automatically when relevant. This layer is never planned. It grows one correction at a time and compounds.

**Layer 4: Skills.** Repeated workflows get encoded as named skills (morning orientation, end-of-session capture, voice-note processing, status scans). These operationalize the patterns so they run consistently instead of depending on you remembering to ask.

The lesson: the value is not in any single layer. Layer 2 calibrated the behavior, Layer 1 made it persist, Layer 3 made it compound. Build only Layers 0 and 4 and you get a faster assistant. The thought-partner quality lives in 1, 2, and 3.

---

## Part 3: Replication guide (do this in order)

### Step 1: Project + global config

Create a working directory. Add a project `CLAUDE.md`: hard rules, infra facts, constraints, anything that should override default behavior every session. Add a global one for cross-project rules. Keep both lean. This file is loaded every turn, so bloat is expensive.

### Step 2: Stand up the memory system

Use your agent's file-based memory (persists across sessions). Establish a typed schema. The four types that have proven load-bearing:

- **user**: who you are, role, technical level, how you should be worked with
- **feedback**: corrections and validated approaches, each with the *why* so edge cases can be judged later
- **project**: current work, motivations, deadlines, who owns what
- **reference**: pointers to where information lives in external systems

Keep an always-loaded index that points to the rest. Add a session-start ritual that loads only the minimum relevant set, and a session-end ritual that writes new observations. The session-end habit is load-bearing. Skip it and the system stops learning. Treat it as non-optional, the way you treat committing code.

### Step 3: The calibration layer (do not skip, do not copy someone else's)

Get your own assessment data: Clifton StrengthsFinder, an SDI conflict instrument, an Enneagram (iEQ9 preferred for depth), Big Five. The specific instruments matter less than having real, structured data about your actual cognitive and behavioral patterns, including the gaps.

Have the agent read the raw results directly. Do not hand it a self-summary, because the value is in the findings you would not volunteer about yourself. Then have it produce an operating manual with this structure for each rule:

- **The rule** (the counterweight behavior)
- **Why** (the specific assessment finding it derives from)
- **How to apply** (the trigger condition and the concrete action)

Store it as a feedback-type memory. Tell the agent explicitly that this governs collaboration, not just output.

The framing that tends to resonate with builders: this is the same move as encoding a methodology so it executes consistently instead of depending on the practitioner's memory. The operating manual is your collaboration methodology, made executable and persistent.

### Step 4: Let feedback compound

Every time the agent does something you correct, have it save the correction as its own feedback memory with the reasoning. Every time it makes a non-obvious judgment call you endorse, save that too. The second half is the part people miss. If you only save corrections, the system gets cautious and drifts back toward generic. Saving validated calls holds the calibration in place.

This layer is not built in a day. It is built in a hundred small corrections. Budget for that.

### Step 5: Encode repeated workflows as skills

Once a workflow repeats, make it a skill so it runs the same way every time. This is the last layer for a reason. Premature skill-building encodes workflows you have not validated yet.

---

## Part 4: The maintenance discipline

This system has a real upkeep cost. Underestimating it is a common blind spot, so it is stated plainly.

- **Session-end capture is the keystone habit.** Skip it and the memory goes stale, the calibration stops compounding, and within weeks you are back to a generic assistant with extra config files.
- **Memory files decay.** Project state especially. A scheduled review keeps the system from acting on stale facts.
- **The index has a load ceiling.** It is read every turn. Keep it an index, not a dumping ground.

If you are not willing to run session-end consistently, build Layers 0 and 4 only and skip the rest. A half-maintained memory system is worse than none, because it will confidently act on outdated context.

---

## What copies and what does not

| Element | Copies? |
|---|---|
| Project + global config structure | Yes, directly |
| Memory system architecture and schema | Yes, directly |
| The calibration *process* (assess, read raw, translate to triggered rules) | Yes, directly |
| Anyone's actual operating-manual content | No. Build your own from your own data. |
| The session-end / session-start discipline | Yes, and it is mandatory for the rest to work |
| Compounding feedback mechanism | Yes, directly |

One-line summary: the architecture is shareable, the calibration is yours alone, and the calibration is the part that makes it a thought partner instead of a faster autocomplete.

---

## The two skills that operationalize this

This playbook ships two bonus skills (`bonus-skills/`) that put the counterweight behavior into practice on demand:

- **`strategic-partner`**: runs a planning/thinking session as a partner who challenges assumptions, sequences instead of piling, and self-critiques before presenting.
- **`strategic-lenses`**: applies a named toolkit of decision lenses (first principles, inversion, pre-mortem, steelman, red team, and more) to stress-test any artifact or decision before you act on it.

Install them the same way as the session skills in `QUICKSTART.md`.
